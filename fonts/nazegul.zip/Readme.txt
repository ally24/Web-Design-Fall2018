First of All,

Thank you for download my product.
This product free for personal use.
If you want the full version and license for commercial use,
you can purchase here:

https://creativemarket.com/gunastudio/3733808-Nazegul-Elegant-Typeface

-------------------------------------------

File include : 

1. Nazegul.ttf

Paypal account for donation : https://www.paypal.me/fandikoerniawan

More Info : 
hello.gunastudio@gmail.com

My OnlineShop:
https://creativemarket.com/gunastudio

My Portofolio:
https://www.behance.net/Gunastudio